// main.js - メインページの処理

document.addEventListener('DOMContentLoaded', async function() {
    // ログイン確認
    checkLoginStatus();
    
    // 管理者権限確認と適切な表示設定
    const currentUser = getCurrentUser();
    const isAdmin = currentUser && currentUser.isAdmin;
    
    // デバッグ用ログ
    console.log('Current User:', currentUser);
    console.log('Is Admin:', isAdmin);
    
    if (isAdmin) {
        console.log('管理者モードを開始します');
        // 管理者用：1ヶ月分のヘッダーを生成
        generateAdminDateHeaders();
        // 管理者UIを表示
        showAdminInterface();
    } else {
        console.log('一般ユーザーモードを開始します');
        // 一般ユーザー用：8日分のヘッダーを生成
        generateDateHeaders();
    }
    
    // 全ユーザーを読み込んで表示
    await loadAllUsers();
    
    // 日付選択オプションを生成
    generateDateOptions();
    
    // 名前選択オプションを生成（管理者の場合のみ表示）
    generateNameOptions();
    
    // 現在時刻をデフォルトに設定
    setCurrentTimeDefault();
    
    // ログアウトボタンの設定
    const logoutButton = document.getElementById('logout-button');
    if (logoutButton) {
        logoutButton.addEventListener('click', logout);
    }
    
    // 風呂チェック送信ボタンの設定
    const bathedButton = document.getElementById('bath-submit-btn');
    const skippedButton = document.getElementById('skip-submit-btn');
    
    if (bathedButton) {
        bathedButton.addEventListener('click', () => submitBathRecord('bathed'));
    }
    
    if (skippedButton) {
        skippedButton.addEventListener('click', () => submitBathRecord('skipped'));
    }
    
    // 全ユーザーの記録を読み込み（非同期）
    loadAllUsers().catch(error => {
        console.error('ユーザー読み込みエラー:', error);
    });
});

// ログイン状態をチェックする関数
function checkLoginStatus() {
    const currentUser = getCurrentUser();
    if (!currentUser) {
        window.location.href = 'login.html';
        return;
    }
}

// 現在のユーザー情報を取得する関数
function getCurrentUser() {
    const userData = localStorage.getItem('currentUser');
    return userData ? JSON.parse(userData) : null;
}

// 昨日から7日後まで8日分の日付を生成する関数
function generateDateHeaders() {
    const today = new Date();
    
    for (let i = 1; i <= 8; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + (i - 2)); // 昨日から7日後まで
        
        const dayElement = document.getElementById(`day-${i}`);
        if (dayElement) {
            // クラスを追加
            dayElement.className = 'date-header';
            
            // 月/日 (曜日) の形式で表示
            const month = date.getMonth() + 1;
            const day = date.getDate();
            const dayOfWeek = ['日', '月', '火', '水', '木', '金', '土'][date.getDay()];
            
            let dateText = `${month}/${day} (${dayOfWeek})`;
            
            // 特別な表示を追加
            if (i === 1) {
                dateText = `昨日\n${dateText}`;
            } else if (i === 2) {
                // 今日の列にはクラスのみ追加（「今日」テキストは表示しない）
                dayElement.classList.add('today');
            } else if (i === 3) {
                dateText = `明日\n${dateText}`;
            }
            
            dayElement.innerHTML = dateText.replace('\n', '<br>');
        }
    }
}

// 管理者用：1ヶ月分（30日）の日付ヘッダーを生成する関数
function generateAdminDateHeaders() {
    console.log('管理者用ヘッダー生成を開始します');
    const today = new Date();
    const headerRow = document.querySelector('#bath-table thead tr');
    
    if (!headerRow) {
        console.error('ヘッダー行が見つかりません');
        return;
    }
    
    // 既存のヘッダーをクリア（名前列以外）
    const existingHeaders = headerRow.querySelectorAll('th:not(.name-header)');
    console.log('削除する既存ヘッダー数:', existingHeaders.length);
    existingHeaders.forEach(header => header.remove());
    
    // 30日分のヘッダーを生成
    for (let i = 0; i < 30; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - 29 + i); // 29日前から今日まで
        
        const th = document.createElement('th');
        th.className = 'date-header admin-date';
        th.id = `admin-day-${i + 1}`;
        
        const month = date.getMonth() + 1;
        const day = date.getDate();
        const dayOfWeek = ['日', '月', '火', '水', '木', '金', '土'][date.getDay()];
        
        let dateText = `${month}/${day}`;
        
        // 今日をハイライト（「今日」テキストは表示しない）
        if (i === 29) {
            th.classList.add('today');
        }
        
        th.innerHTML = `${dateText}<br>(${dayOfWeek})`;
        headerRow.appendChild(th);
    }
    
    console.log('管理者用ヘッダー生成完了 - 30日分');
}

// 管理者用UIを表示する関数
function showAdminInterface() {
    console.log('管理者用UI設定を開始します');
    
    // ページタイトルを変更
    const titleElement = document.querySelector('h1');
    if (titleElement) {
        titleElement.textContent = '風呂チェック表 - 管理者ビュー（1ヶ月分）';
        titleElement.style.color = '#d32f2f';
        console.log('タイトルを管理者ビューに変更しました');
    }
    
    // 管理者メッセージを追加
    const container = document.querySelector('.container');
    if (container) {
        const adminMessage = document.createElement('div');
        adminMessage.className = 'admin-message';
        adminMessage.innerHTML = `
            <p>
                <strong>🔧 管理者モード</strong> - 過去30日間のすべてのデータを表示中
            </p>
        `;
        container.insertBefore(adminMessage, container.firstChild);
        console.log('管理者メッセージを追加しました');
    }
    
    // テーブルに管理者用クラスを追加
    const table = document.getElementById('bath-table');
    const tableContainer = document.querySelector('.table-container');
    if (table) {
        table.classList.add('admin-view');
        console.log('テーブルに管理者クラスを追加しました');
    }
    if (tableContainer) {
        tableContainer.classList.add('admin-view');
        console.log('テーブルコンテナに管理者クラスを追加しました');
    }
}

// 全ユーザーの風呂記録を読み込む関数
async function loadAllUsers() {
    let allUsers = JSON.parse(localStorage.getItem('allUsers')) || [];
    const currentUser = getCurrentUser();
    
    // allUsersが空の場合、users.jsonから読み込み
    if (allUsers.length === 0) {
        try {
            const response = await fetch('./json/users.json');
            if (response.ok) {
                allUsers = await response.json();
                localStorage.setItem('allUsers', JSON.stringify(allUsers));
            } else {
                showEmptyState();
                return;
            }
        } catch (error) {
            console.error('ユーザーデータの読み込みエラー:', error);
            showEmptyState();
            return;
        }
    }
    
    const bathTableBody = document.getElementById('bath-table-body');
    const bathTable = document.getElementById('bath-table');
    
    bathTableBody.innerHTML = '';
    
    // 管理者かどうかで表示する日数を決定
    const isAdmin = currentUser && currentUser.isAdmin;
    const daysToShow = isAdmin ? 30 : 8;
    
    // テーブルにクラス付与
    if (isAdmin) {
        bathTable.classList.add('admin-view');
        document.querySelector('.table-container').classList.add('admin-view');
    } else {
        bathTable.classList.remove('admin-view');
        document.querySelector('.table-container').classList.remove('admin-view');
    }
    
    // ヘッダーを動的に生成
    if (isAdmin) {
        generateAdminDateHeaders();
    } else {
        generateDateHeaders();
    }
    
    // 各ユーザーの行を生成（管理者は除外）
    allUsers.filter(user => !user.isAdmin).forEach(user => {
        const isCurrentUser = currentUser && currentUser.userid === user.userid;
        const row = document.createElement('tr');
        
        // 名前セル
        const nameCell = document.createElement('td');
        nameCell.textContent = user.name;
        nameCell.className = 'name-cell';
        
        if (isCurrentUser) {
            nameCell.classList.add('current-user');
        }
        
        row.appendChild(nameCell);
        
        // マークセルを生成（管理者は30日分、一般は8日分）
        for (let i = 1; i <= daysToShow; i++) {
            const markCell = document.createElement('td');
            markCell.className = 'bath-mark-cell';
            markCell.id = `mark-${user.userid}-day-${i}`;
            
            // 日付キーを取得（管理者と一般で異なる計算）
            const dateKey = isAdmin ? getAdminDateKeyForDay(i) : getDateKeyForDay(i);
            const recordKey = `bathRecord_${user.userid}_${dateKey}`;
            const bathRecord = JSON.parse(localStorage.getItem(recordKey));
            
            // 3状態ボタンを作成（未記録・入浴・未入浴）
            const markButton = document.createElement('button');
            markButton.className = 'bath-mark-btn';
            markButton.id = `btn-${user.userid}-day-${i}`;
            
            // 現在の状態を確認（bathRecord.status: null=未記録, 'bathed'=入浴, 'skipped'=未入浴）
            let currentStatus = 'none'; // デフォルト: 未記録
            let buttonText = '―';
            let tooltipText = 'クリックして記録';
            
            if (bathRecord) {
                if (bathRecord.status === 'skipped') {
                    currentStatus = 'skipped';
                    buttonText = '❌';
                    tooltipText = `未入浴\nメモ: ${bathRecord.memo || 'なし'}`;
                } else {
                    currentStatus = 'bathed';
                    buttonText = '♨️';
                    tooltipText = `入浴済み\n時間: ${bathRecord.time}\nメモ: ${bathRecord.memo || 'なし'}`;
                }
            }
            
            markButton.textContent = buttonText;
            markButton.className += ` status-${currentStatus}`;
            markButton.title = tooltipText;
            
            // クリック機能を追加（内容表示・削除確認）
            markButton.disabled = false;
            markButton.className += ' clickable';
            markButton.style.cursor = 'pointer';
            
            // 権限チェック
            const canDelete = (currentUser && currentUser.userid === user.userid) || (currentUser && currentUser.isAdmin);
            const canEdit = (currentUser && currentUser.userid === user.userid) || (currentUser && currentUser.isAdmin);
            
            // クリックイベントの設定
            if (bathRecord) {
                // 記録がある場合：左クリックで詳細表示、右クリックで状態変更（管理者のみ）
                markButton.addEventListener('click', async function(e) {
                    e.preventDefault();
                    await showRecordDetailsWithDelete(bathRecord, user.name, dateKey, user.userid, canDelete);
                });
                
                // 管理者は右クリックで状態変更可能
                if (currentUser && currentUser.isAdmin) {
                    markButton.addEventListener('contextmenu', async function(e) {
                        e.preventDefault();
                        await cycleBathStatus(user.userid, dateKey, currentStatus);
                    });
                    markButton.title += canDelete ? '\n\n🖱️ 左クリック：詳細表示・削除\n🖱️ 右クリック：状態変更' : '\n\n🖱️ 左クリック：詳細表示\n🖱️ 右クリック：状態変更';
                } else {
                    markButton.title += canDelete ? '\n\n🖱️ クリックで詳細表示・削除' : '\n\n🖱️ クリックで詳細表示';
                }
                
                markButton.style.textDecoration = 'underline';
            } else if (canEdit) {
                // 記録がない場合で編集権限がある場合：クリックで状態変更
                markButton.addEventListener('click', async function(e) {
                    e.preventDefault();
                    await cycleBathStatus(user.userid, dateKey, currentStatus);
                });
                markButton.title += '\n\n🖱️ クリックして記録';
            } else {
                markButton.title = '記録なし';
            }
            
            markCell.appendChild(markButton);
            row.appendChild(markCell);
        }
        
        bathTableBody.appendChild(row);
    });
    
    // 名前選択オプションも更新（管理者の場合）
    generateNameOptions();
}

// 日付キーを生成する関数
function getCurrentDateKey() {
    const today = new Date();
    return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
}

// 指定した日数後の日付キーを取得する関数（昨日を-1日として計算）
function getDateKeyForDay(dayNumber) {
    const today = new Date();
    const targetDate = new Date(today);
    // dayNumber 1=昨日、2=今日、3=明日... という形に変更
    targetDate.setDate(today.getDate() + (dayNumber - 2));
    return `${targetDate.getFullYear()}-${String(targetDate.getMonth() + 1).padStart(2, '0')}-${String(targetDate.getDate()).padStart(2, '0')}`;
}

// 管理者用：30日分の日付キーを取得する関数
function getAdminDateKeyForDay(dayNumber) {
    const today = new Date();
    const targetDate = new Date(today);
    // dayNumber 1=29日前、2=28日前、...、30=今日
    targetDate.setDate(today.getDate() - 30 + dayNumber);
    return `${targetDate.getFullYear()}-${String(targetDate.getMonth() + 1).padStart(2, '0')}-${String(targetDate.getDate()).padStart(2, '0')}`;
}

// フォーム用：選択された番号から日付キーを取得
function getDateKeyFromSelectValue(selectValue) {
    const currentUser = getCurrentUser();
    const isAdmin = currentUser && currentUser.isAdmin;
    
    if (isAdmin) {
        // 管理者用：30日分対応
        return getAdminDateKeyForDay(selectValue);
    } else {
        // 一般ユーザー用：8日分対応
        const today = new Date();
        const targetDate = new Date(today);
        // selectValue: 1=昨日、2=今日、3=明日...
        targetDate.setDate(today.getDate() + (selectValue - 2));
        return `${targetDate.getFullYear()}-${String(targetDate.getMonth() + 1).padStart(2, '0')}-${String(targetDate.getDate()).padStart(2, '0')}`;
    }
}

// 日付選択オプションを生成する関数
function generateDateOptions() {
    const dateSelect = document.getElementById('bath-date');
    if (!dateSelect) return;
    
    const currentUser = getCurrentUser();
    const isAdmin = currentUser && currentUser.isAdmin;
    
    if (isAdmin) {
        generateAdminDateOptions();
    } else {
        generateNormalDateOptions();
    }
}

// 一般ユーザー用：昨日から7日後まで8日分の日付オプション
function generateNormalDateOptions() {
    const dateSelect = document.getElementById('bath-date');
    const today = new Date();
    const dayNames = ['日', '月', '火', '水', '木', '金', '土'];
    
    // 昨日から7日後まで（8日分）
    for (let i = 1; i <= 8; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + (i - 2)); // i=1で昨日、i=2で今日
        
        const option = document.createElement('option');
        option.value = i;
        
        let dateLabel = `${date.getMonth() + 1}/${date.getDate()} (${dayNames[date.getDay()]})`;
        
        // 特別な表示を追加
        if (i === 1) {
            dateLabel = `昨日 ${dateLabel}`;
        } else if (i === 2) {
            dateLabel = `今日 ${dateLabel}`;
        } else if (i === 3) {
            dateLabel = `明日 ${dateLabel}`;
        }
        
        option.textContent = dateLabel;
        
        // 今日をデフォルト選択
        if (i === 2) {
            option.selected = true;
        }
        
        dateSelect.appendChild(option);
    }
}

// 管理者用：30日分の日付オプション
function generateAdminDateOptions() {
    const dateSelect = document.getElementById('bath-date');
    const today = new Date();
    const dayNames = ['日', '月', '火', '水', '木', '金', '土'];
    
    // 30日分（29日前から今日まで）
    for (let i = 1; i <= 30; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - 30 + i); // i=1で29日前、i=30で今日
        
        const option = document.createElement('option');
        option.value = i;
        
        let dateLabel = `${date.getMonth() + 1}/${date.getDate()} (${dayNames[date.getDay()]})`;
        
        // 今日の場合の特別な表示
        if (i === 30) {
            dateLabel = `${dateLabel}`;
            option.selected = true;
        }
        
        option.textContent = dateLabel;
        dateSelect.appendChild(option);
    }
}

// 名前選択オプションを生成（管理者用）
function generateNameOptions() {
    const nameSelectRow = document.getElementById('name-select-row');
    const nameSelect = document.getElementById('bath-name');
    const currentUser = getCurrentUser();
    
    // 管理者でない場合は名前選択を非表示
    if (!currentUser || !currentUser.isAdmin) {
        if (nameSelectRow) {
            nameSelectRow.style.display = 'none';
        }
        return;
    }
    
    // 管理者の場合は名前選択を表示
    if (nameSelectRow) {
        nameSelectRow.style.display = 'flex';
    }
    
    if (!nameSelect) return;
    
    // 既存のオプションをクリア
    nameSelect.innerHTML = '';
    
    // allUsersからユーザーリストを取得
    const allUsers = JSON.parse(localStorage.getItem('allUsers')) || [];
    
    // 管理者以外のユーザーをオプションに追加
    allUsers.filter(user => !user.isAdmin).forEach(user => {
        const option = document.createElement('option');
        option.value = user.userid;
        option.textContent = user.name;
        nameSelect.appendChild(option);
    });
    
    // デフォルト選択（最初のユーザー）
    if (nameSelect.options.length > 0) {
        nameSelect.selectedIndex = 0;
    }
}

// 現在時刻をデフォルトに設定
function setCurrentTimeDefault() {
    const timeInput = document.getElementById('bath-time');
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    timeInput.value = `${hours}:${minutes}`;
}

// 風呂記録を保存する関数
function submitBathRecord(status) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        alert('ログインしてください。');
        return;
    }
    
    const timeInput = document.getElementById('bath-time');
    const memoInput = document.getElementById('bath-memo');
    const dateSelect = document.getElementById('bath-date');
    const nameSelect = document.getElementById('bath-name');
    
    const time = timeInput.value;
    const memo = memoInput.value;
    const dayNumber = parseInt(dateSelect.value);
    
    // 記録対象のユーザーIDを決定
    let targetUserId;
    if (currentUser.isAdmin && nameSelect && nameSelect.value) {
        // 管理者の場合：選択された名前のユーザーID
        targetUserId = nameSelect.value;
    } else {
        // 一般ユーザーの場合：自分のユーザーID
        targetUserId = currentUser.userid;
    }
    
    // 入浴の場合は時間が必要、未入浴の場合は不要
    if (status === 'bathed' && !time) {
        alert('入浴時間を入力してください。');
        return;
    }
    
    // 記録を保存
    const dateKey = getDateKeyFromSelectValue(dayNumber);
    const recordKey = `bathRecord_${targetUserId}_${dateKey}`;
    
    const bathRecord = {
        status: status,
        time: status === 'bathed' ? time : null,
        memo: memo,
        date: dateKey,
        timestamp: new Date().toISOString()
    };
    
    localStorage.setItem(recordKey, JSON.stringify(bathRecord));
    
    // フォームをリセット
    timeInput.value = '';
    memoInput.value = '';
    setCurrentTimeDefault();
    
    // 表を再読み込み
    loadAllUsers().catch(error => console.error('テーブル再読み込みエラー:', error));
    
    const message = status === 'bathed' ? '入浴記録を保存しました！' : '未入浴記録を保存しました！';
    alert(message);
}

// 記録詳細を表示する関数
function showRecordDetails(bathRecord, userName, dateKey) {
    const date = new Date(dateKey);
    const formattedDate = `${date.getMonth() + 1}/${date.getDate()}`;
    
    let detailContent = `【${userName}さんの記録】\n`;
    detailContent += `日付: ${formattedDate}\n`;
    
    if (bathRecord.status === 'bathed') {
        detailContent += `状態: 入浴済み ♨️\n`;
        if (bathRecord.time) {
            detailContent += `時間: ${bathRecord.time}\n`;
        }
    } else if (bathRecord.status === 'skipped') {
        detailContent += `状態: 未入浴 ❌\n`;
    }
    
    if (bathRecord.memo) {
        detailContent += `メモ: ${bathRecord.memo}\n`;
    }
    
    if (bathRecord.timestamp) {
        const recordDate = new Date(bathRecord.timestamp);
        const recordTime = recordDate.toLocaleString('ja-JP');
        detailContent += `\n記録日時: ${recordTime}`;
    }
    
    // メモ表示エリアに表示
    const memoDisplay = document.getElementById('memo-display');
    const memoContent = document.getElementById('memo-content');
    
    if (memoDisplay && memoContent) {
        memoContent.textContent = detailContent;
        memoDisplay.style.display = 'block';
        memoDisplay.scrollIntoView({ behavior: 'smooth' });
    } else {
        // フォールバック：アラートで表示
        alert(detailContent);
    }
}

// 記録詳細表示＋削除確認機能
async function showRecordDetailsWithDelete(bathRecord, userName, dateKey, userId, canDelete) {
    const date = new Date(dateKey);
    const formattedDate = `${date.getMonth() + 1}/${date.getDate()}`;
    
    let detailContent = `【${userName}さんの記録】\n`;
    detailContent += `日付: ${formattedDate}\n`;
    
    if (bathRecord.status === 'bathed') {
        detailContent += `状態: 入浴済み ♨️\n`;
        if (bathRecord.time) {
            detailContent += `時間: ${bathRecord.time}\n`;
        }
    } else if (bathRecord.status === 'skipped') {
        detailContent += `状態: 未入浴 ❌\n`;
    }
    
    if (bathRecord.memo) {
        detailContent += `メモ: ${bathRecord.memo}\n`;
    }
    
    if (bathRecord.timestamp) {
        const recordDate = new Date(bathRecord.timestamp);
        const recordTime = recordDate.toLocaleString('ja-JP');
        detailContent += `\n記録日時: ${recordTime}`;
    }
    
    // 削除ボタンを追加するかどうか
    if (canDelete) {
        detailContent += '\n\n🗑️ この記録を削除しますか？';
        
        if (confirm(detailContent + '\n\n「OK」で削除、「キャンセル」で閉じる')) {
            await deleteRecord(userId, dateKey);
        }
    } else {
        // 削除権限がない場合は詳細表示のみ
        showRecordDetails(bathRecord, userName, dateKey);
    }
}

// 記録削除機能
async function deleteRecord(userId, dateKey) {
    const recordKey = `bathRecord_${userId}_${dateKey}`;
    const bathRecord = JSON.parse(localStorage.getItem(recordKey));
    
    if (!bathRecord) {
        alert('削除する記録が見つかりません。');
        return;
    }
    
    // 確認メッセージ
    const deleteMessage = `本当に削除しますか？\n\nこの操作は取り消せません。`;
    
    if (confirm(deleteMessage)) {
        // ローカルストレージから削除
        localStorage.removeItem(recordKey);
        
        // 表を再読み込み
        await loadAllUsers();
        
        alert('記録を削除しました。');
    }
}

// メモ表示エリアを隠す関数
function hideMemoDisplay() {
    const memoDisplay = document.getElementById('memo-display');
    if (memoDisplay) {
        memoDisplay.style.display = 'none';
    }
}

// 管理者用：3状態を循環させる関数（未記録 → 入浴 → 未入浴 → 未記録...）
async function cycleBathStatus(userId, dateKey, currentStatus) {
    const recordKey = `bathRecord_${userId}_${dateKey}`;
    const currentUser = getCurrentUser();
    
    // 権限チェック
    if (!currentUser || (currentUser.userid !== userId && !currentUser.isAdmin)) {
        alert('記録を変更する権限がありません。');
        return;
    }
    
    let nextStatus;
    let recordData;
    
    switch (currentStatus) {
        case 'none':
            // 未記録 → 入浴済み
            nextStatus = 'bathed';
            const currentTime = new Date().toLocaleTimeString('ja-JP', {
                hour: '2-digit',
                minute: '2-digit'
            });
            recordData = {
                status: 'bathed',
                time: currentTime,
                memo: '',
                date: dateKey,
                timestamp: new Date().toISOString()
            };
            break;
            
        case 'bathed':
            // 入浴済み → 未入浴
            const existingRecord = JSON.parse(localStorage.getItem(recordKey));
            nextStatus = 'skipped';
            recordData = {
                status: 'skipped',
                time: null,
                memo: existingRecord ? existingRecord.memo : '',
                date: dateKey,
                timestamp: new Date().toISOString()
            };
            break;
            
        case 'skipped':
            // 未入浴 → 未記録（削除）
            nextStatus = 'none';
            localStorage.removeItem(recordKey);
            await loadAllUsers();
            return;
    }
    
    // データを保存
    localStorage.setItem(recordKey, JSON.stringify(recordData));
    
    // 表を再読み込み
    await loadAllUsers();
}

// 風呂の状態を循環させる関数（未記録 → 入浴 → 未入浴 → 未記録...）
// ※テーブル表示専用になったため、この関数は現在未使用
/*
function cycleBathStatus(userId, dateKey, dayIndex, currentStatus) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    // 権限チェック
    if (!currentUser || (currentUser.userid !== userId && !currentUser.isAdmin)) {
        alert('記録を変更する権限がありません。');
        return;
    }
    
    const recordKey = `bathRecord_${userId}_${dateKey}`;
    let nextStatus;
    let recordData;
    
    // 状態の循環: none → bathed → skipped → none
    switch (currentStatus) {
        case 'none':
            // 未記録 → 入浴済み
            nextStatus = 'bathed';
            const currentTime = new Date().toLocaleTimeString('ja-JP', {
                hour: '2-digit',
                minute: '2-digit'
            });
            recordData = {
                status: 'bathed',
                time: currentTime,
                memo: '',
                date: dateKey
            };
            break;
            
        case 'bathed':
            // 入浴済み → 未入浴
            const existingRecord = JSON.parse(localStorage.getItem(recordKey));
            nextStatus = 'skipped';
            recordData = {
                status: 'skipped',
                time: null,
                memo: existingRecord ? existingRecord.memo : '',
                date: dateKey
            };
            break;
            
        case 'skipped':
            // 未入浴 → 未記録（削除）
            nextStatus = 'none';
            localStorage.removeItem(recordKey);
            loadAllUsers();
            return;
    }
    
    // データを保存
    localStorage.setItem(recordKey, JSON.stringify(recordData));
    
    // 表を再読み込み
    loadAllUsers();
}
*/

// 風呂記録を削除する関数（旧版・現在未使用）
/*
function deleteBathRecord(userId, dateKey, dayNumber) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    // 自分の記録のみ削除可能
    if (!currentUser || currentUser.userid !== userId) {
        alert('自分の記録のみ削除できます。');
        return;
    }
    
    const recordKey = `bathRecord_${userId}_${dateKey}`;
    const bathRecord = JSON.parse(localStorage.getItem(recordKey));
    
    if (!bathRecord) {
        alert('削除する記録が見つかりません。');
        return;
    }
    
    // 削除確認
    const confirmMessage = `風呂チェック記録を削除しますか？\n\n時間: ${bathRecord.time}\nメモ: ${bathRecord.memo || 'なし'}`;
    
    if (confirm(confirmMessage)) {
        // ローカルストレージから削除
        localStorage.removeItem(recordKey);
        
        // 表を再読み込み
        loadAllUsers();
        
        alert('記録を削除しました。');
    }
}
*/

// ログアウト機能
function logout() {
    if (confirm('ログアウトしますか？')) {
        // ローカルストレージからログイン情報を削除
        localStorage.removeItem('currentUser');
        localStorage.removeItem('isLoggedIn');
        
        // ログイン画面に遷移
        window.location.href = 'login.html';
    }
}