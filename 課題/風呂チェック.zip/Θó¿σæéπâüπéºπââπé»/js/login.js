// login.js - ログイン画面の処理

document.addEventListener('DOMContentLoaded', function() {
    const loginButton = document.getElementById('login-button');
    const idInput = document.getElementById('id');
    const passwordInput = document.getElementById('password');
    const passwordToggle = document.getElementById('password-toggle');
    
    // ユーザー一覧を読み込んで表示
    loadUserAccounts();
    
    // パスワード表示/非表示の切り替え
    passwordToggle.addEventListener('click', function() {
        if (passwordInput.type === 'password') {
            // パスワードを表示状態にする
            passwordInput.type = 'text';
            passwordToggle.innerHTML = `
                <svg class="eye-slash-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94L17.94 17.94z"/>
                    <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19l-6.84-6.84"/>
                    <path d="M1 1l22 22"/>
                    <circle cx="12" cy="12" r="3"/>
                </svg>
            `;
            passwordToggle.classList.add('hidden');
        } else {
            // パスワードを非表示状態にする
            passwordInput.type = 'password';
            passwordToggle.innerHTML = `
                <svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                </svg>
            `;
            passwordToggle.classList.remove('hidden');
        }
    });
    
    // ログインボタンのクリックイベント
    loginButton.addEventListener('click', function() {
        // 入力値を取得
        const userId = idInput.value.trim();
        const password = passwordInput.value.trim();
        
        // 入力チェック
        if (!userId) {
            alert('IDを入力してください。');
            idInput.focus(); // IDフィールドにフォーカスを移す
            return;
        }
        
        if (!password) {
            alert('パスワードを入力してください。');
            passwordInput.focus(); // パスワードフィールドにフォーカスを移す
            return;
        }
        
        if (password.length < 4) {
            alert('パスワードは4文字以上で入力してください。');
            passwordInput.focus();
            return;
        }
        
        // パスワードが数字4桁かチェック
        if (!/^\d{4}$/.test(password)) {
            alert('パスワードは4桁の数字で入力してください。');
            passwordInput.focus();
            return;
        }
        
        // 実際のログイン処理（ここでは簡単な例）
        // 実際のアプリでは、サーバーとの認証処理を行います
        performLogin(userId, password);
    });
    
    // Enterキーでもログインできるようにする
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            loginButton.click();
        }
    });
});

// ログイン処理
async function performLogin(userId, password) {
    try {
        // JSONファイルからユーザー情報を読み込み
        const response = await fetch('./json/users.json');
        
        if (!response.ok) {
            alert('ユーザーデータを読み込めませんでした。管理者にお問い合わせください。');
            return;
        }
        
        const users = await response.json();
        
        // ユーザーIDとパスワードをチェック
        const user = users.find(u => u.userid === userId && u.password === password);
        
        if (user) {
            // ログイン成功
            alert(`ようこそ、${user.name}さん！`);
            
            // ログイン情報を保存（次回のために）
            localStorage.setItem('currentUser', JSON.stringify(user));
            
            // 全ユーザー情報も保存（メイン画面で使用）
            localStorage.setItem('allUsers', JSON.stringify(users));
            
            // メイン画面に遷移
            location.href = 'index.html';
        } else {
            // ログイン失敗
            alert('IDまたはパスワードが間違っています。');
            
            // 入力フィールドをクリア
            document.getElementById('password').value = '';
            document.getElementById('id').focus();
        }
        
    } catch (error) {
        console.error('ログイン処理でエラーが発生しました:', error);
        alert('ログイン処理中にエラーが発生しました。再度お試しください。');
    }
}

// ユーザーアカウント一覧を読み込んで表示する関数
async function loadUserAccounts() {
    try {
        const response = await fetch('./json/users.json');
        if (!response.ok) {
            console.error('ユーザーデータの読み込みに失敗しました');
            return;
        }
        
        const users = await response.json();
        const accountsContainer = document.getElementById('user-accounts');
        
        if (!accountsContainer) {
            console.error('ユーザー一覧コンテナが見つかりません');
            return;
        }
        
        // ユーザーアカウントを表示
        accountsContainer.innerHTML = '';
        users.forEach(user => {
            const accountDiv = document.createElement('div');
            accountDiv.className = `user-account ${user.isAdmin ? 'admin' : ''}`;
            
            // クリックで自動入力
            accountDiv.addEventListener('click', function() {
                document.getElementById('id').value = user.userid;
                document.getElementById('password').value = user.password;
                // フォーカスをログインボタンに移す
                document.getElementById('login-button').focus();
            });
            
            accountDiv.innerHTML = `
                <div class="user-name">
                    ${user.name}
                    ${user.isAdmin ? '<span class="admin-badge">管理者</span>' : ''}
                </div>
                <div class="user-relation">${user.relation}</div>
                <div class="user-credentials">
                    <div class="user-id">ID: ${user.userid}</div>
                    <div class="user-password">パス: ${user.password}</div>
                </div>
            `;
            
            accountsContainer.appendChild(accountDiv);
        });
        
    } catch (error) {
        console.error('ユーザーアカウント一覧の読み込みでエラーが発生しました:', error);
    }
}
